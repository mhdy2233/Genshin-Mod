Mod Made by Ararani (ararani on discord) with love~
This mod is available for free in discord.gg/agmg and Gamebanana site.