Swag Venti made by Murren and Anilyan.
Available at https://www.patreon.com/Lewd_Lad/memberships (Men tier) and https://www.patreon.com/mimarimods
Time spent: 30+ Hours.

For usage with 3DM GIMI (Genshin Impact Model Importer)
https://github.com/SilentNightSound/GI-Model-Importer
Big Thanks to SilentNightSound for their work.
Buy them a coffee to help encourage the continued development of all these fantastic tools!
https://ko-fi.com/silentnightsound

Provided under 
Creative_Commons_Attribution-NonCommercial-NoDerivatives_4.0_International_CC_BY-NC-ND_4.0

No commercial usage.

If you wish to make media using this mod, please contact me via Patreon, Discord or Twitter.

No derivative works allowed.

By Murren and Anilyan, based on art by Isaky.
Source Art by Isaky.
Modelling and weighting of Venti by Murren.
Texturing of Venti by Anilyan.
Recolor/port of Venti's Lyre to the Stringless by Murren.
Port of Dvalin to Endora by Murren.

Source: https://twitter.com/isaky_tm/status/1354205906498682880

Murren:
Gamebanana: https://gamebanana.com/members/2532615
Twitter: @MurrenMods
Discord: Mvrren
Youtube: https://www.youtube.com/@MurrenMods
Links: https://www.patreon.com/Murren

Anilyan:
Gamebanana: https://gamebanana.com/members/2591983
Twitter: @Anilyan13
Instagram: @ari.genshin_skins

If you paid for this mod outside of early access on Patreon, you were cheated. 
Let me know and I'll see what I can do about it.