Venus Vacation Mod Maker v0.7
=============================

Thread on LoversLab: https://www.loverslab.com/topic/144105-venus-vacation-mod-manager-v12/

A tool to help with writing code for Venus Vacation mods. Will help with importing resources to your mods, overriding textures and models and adding keyboard shortcuts. Everything is automated now!

How to use:

- IMPORTANT: Put VV_ModMaker.exe in your Venus Vacation folder.
- In game enable hunting mode and make a frame dump of the outfit you want to modify.
- In Mod Maker click on the Load button.

From the hash list you can start working with hashes - checking the hash or specific index will add them into mod's .ini file. Use right click to access menu with different options:

- key: allow to assign a hotkey for the hash, hotkeys can be added in the Buttons section.
- t0-t3, ib, vb: allows to override textures and models using resources which can be loaded from Resources section.
- handling: allows to enable or disable skipping of the hash while keeping it in the code (for texture swaps for example).

This is still an early version of the app, but I hope it can help with tedious part of modding. Bugs and crashes are possible.

Creation of visual menus:

Starting with version 0.5 you can create visual menus for your mods similar to the menu used in CostumeCustomizer mod.

Menu creation guide:

1) Right click on the Menu branch and add menu items.
2) There're different kind of menus:
- toggle: will switch between variable's value and 0.
- cycle: will cycle from 0 to variable's value.
- set: will set variable to assigned value.
- commandlist: will run assigned CommandList.
- sub: a submenu which can have all of the above items.
3) Right click on the Variables branch to add the parameters your mod works with.
4) Load filenames of pictures you'll use in your menu with Load filenames button. Pictures should be put inside [your_mod]\resources folder along with files required for the menu.
5) Add hotkeys and assign them to the Menu branch. Choose the menu show condition - best use the same as your mod is using.
6) Assign menu types, pictures, variables and values to menu items. Then right click on the Menu branch and hit "generate".
7) You can add text descriptions for menu items using the "tooltip" menu option.
8) Copy/paste the code to the begging or the end of your .ini file. If you did everything correctly it should work.

Menu options:
initial x/y - coordinates where menu will start drawning (grid is from -1 to 1)
menu width/height - size of the menu items, can be changed separately for submenus
click scale - how much menu item will react on click
border width - how thick menu item's border will be
items in row - after reaching the value submenu will start to draw the second raw of items (then third and so on)

For the more indepth guide please check the thread on LoversLab:
https://www.loverslab.com/topic/144105-venus-vacation-mod-manager-v12/

==============================

Huge thanks to KuroKaze78 since some of his code was used as reference for creating these menus!

==============================

For more information about the modding I recommend amazing tutorial from DarkStarSword: https://www.youtube.com/watch?v=zWE0xP4MgR8

==============================

If you like my work please consider supporting me via PayPal: 

https://paypal.me/avenger54

==============================

Update log:

v0.7
- added a lot of menu customization options

v0.5
- added creation of visual menus for mods

v0.4
- added texture hashes to the list

v0.3
- resources management added

v0.2
- hotkeys assign added

v0.1
- initial release