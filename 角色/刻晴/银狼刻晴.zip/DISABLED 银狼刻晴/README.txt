to swap to original keqing hair color and iris, delete KeqingHeadDiffuse, and then rename KeqingHeadDiffuseKQ to KeqingHeadDiffuse
