The original mod was made by MrLGamer and can be found here: https://gamebanana.com/mods/392549
It ported Bronya's Arc City Blues Outfit from Honkai Impact 3rd to Kokomi as a replacer.
I (Anilyan) just recolored it and changed some patterns on the back to integrate better with Kokomi's colors and aesthetic.